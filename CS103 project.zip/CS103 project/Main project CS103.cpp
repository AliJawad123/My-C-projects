#include<iostream>
#include<string>
#include<stdlib.h>
#include <fstream>
#include<windows.h>

using namespace std;

int prints();

//functions for COE

void coe_login();
void coe();
void create_instructor();
void create_student();
void assign_course();
void student_ID();
void verify_Degree();
void read_message();
void change_password();

//functions for Student

void student_login();
void student();
void verify();

//functions for instructor

void instructor_login();
void instructor();
void veiw_assign_courses();
void grading();
void send_message();
void course_register();
void  student_courses();

int main() {
	system("color B0");
  	int number = prints();
	
	system("cls");
	switch(number) {
    	case 1:
	  		coe_login();                                                                   //coe function is called here
	  		break;
   	 	case 2:
			student_login();                                                    //student login  function is called here
			break;
    	case 3:
			instructor_login();                                                 //instructor login  function is called here
			break;	 	
    	default:
			cout<<"\n\t\t\t\tThank you for going through my project!!!  \n\t\t\t\t";
			system("pause");
			return 0;
    }
}

void coe() {                                                            //    coe function
	int number;
	string stars = string(120, '*');
	
	cout<<stars<<endl;
	cout<<endl;
	
	cout<<"\t\t\t\t COE's Menu "<<endl;
	cout<<stars<<endl;
	cout<<"\t\t\t\t 1.Assign a course to instructor."<<endl<<endl;
	cout<<"\t\t\t\t 2.Create an instructor."<<endl<<endl;
	cout<<"\t\t\t\t 3.Create a Student."<<endl<<endl;
	cout<<"\t\t\t\t 4.Verify Degree of student."<<endl<<endl;
	cout<<"\t\t\t\t 5.Read message from instructor."<<endl<<endl;
	cout<<"\t\t\t\t 6.Change Password."<<endl<<endl;
	cout<<"\t\t\t\t 7.Main menu."<<endl<<endl;
	cout<<stars<<endl<<stars<<endl;
	cout<<endl;
	
	cout<<"\t\t\t\t  Select the option number : ";
	cin>>number;
	
	system("cls");
	if(number==1)
		assign_course();
	else if(number==2)
		create_instructor();
	else if(number==3)
		create_student();
	else if(number==4)
		verify_Degree();
	else if(number==5)	
		read_message();
	else if(number==6)
	   change_password();
	else if(number==7)
		main();	
	else {
		cout<<"*you have enter incorrect option."<<endl;
		system("pause");
	}
}

void create_instructor() {                                 //    function for creating instructor   
	string instructor_name;
	string instructor_ID;
	char option;
	string stars = string(75, '*');
	
	cout<<endl<<"\t\t"<<stars<<endl<<endl;
	cout<<"\t\t\t\t     Instructor Sign up  "<<endl<<endl;
	cout<<endl<<"\t\t"<<stars<<endl<<endl;
	
	ofstream instructor("instructor.txt", ios::app);
	do{
		cin.clear();
		fflush(stdin);
		
		cout<<"\t\t\t\tEnter the instructor name : ";
	    getline(cin,instructor_name);
  	                                                 
		cout<<"\n\t\t\t\tEnter instructor ID (1,2,3..): ";
		getline(cin,instructor_ID);
                       
		instructor<<instructor_name<<endl<<instructor_ID<<endl;
		                                                                     
        cout<<"\n\t\t\t\t*instructor is created successfully!!!";
		cout<<"\n\t\t\t\tDo you want to create another instructor press(y/n): ";
		cin>>option;
		
        cout<<endl;
		
	} while(option != 'n');
	
	instructor.close();
	system("cls");
	coe();
}

void assign_course()                              //  function for assigning course to instructor
{    
	 int button;
	 char choice;
	 string course_name[30],instructor_name[30];
	
	 system("cls");
	 cout<<endl;
	 cout<<"\t\t\t******************************************************************"<<endl<<endl;
	 cout<<"\t\t\t\t\tAssign a course to instructor"<<endl<<endl;
	 cout<<"\t\t\t******************************************************************"<<endl;
	 cout<<endl;
	 int index=0;
	 do
	 {   cin.clear();
		fflush(stdin);
	 	
	 cout<<"\tEnter the instructor name :";getline(cin,instructor_name[index]) ;                              
	 cout<<endl;
	 cout<<"\tEnter the course to assign:";cin>>course_name[index];   ///PH CH 
	 cout<<endl<<endl;
	 cout<<"\t******Course is assigned successfully***";
	 cout<<endl;
	 cout<<"\tDo you want to assign anothercourse for instructor \n\tChoice(y/n)";cin>>choice;
	 if(choice=='y')
	 index++;
	 }
	 while(choice!='n');
	 
	 ofstream file;
	 file.open("Main.txt",ios::app);
	 for(int i=0;i<index;i++)         //index 
	 {
	 file<<instructor_name[i]<<endl;   //index
	 file<<course_name[i]<<endl;
	 }
	 file.close();
	 
	 cout<<"\t\t\t*press 1 to return to COE menu.";cin>>button;
	 if(button==1)
	{ 
	  system("cls");
	  coe();
	}
	 else
	 system("pause");
}
                             
void create_student()                            //   function for creating student
{   
    
    system("cls");
	string student_name;
	string student_ID;
	char option;
	int i=0;
	cout<<endl<<"***************************************************************************"<<endl<<endl;
	cout<<"\t\t    <<< Student Sign in  >>>"<<endl<<endl;
	cout<<endl<<"***************************************************************************"<<endl<<endl;
	ofstream don;
	don.open("create.txt",ios::app);
	do {   
        cin.clear();
		fflush(stdin);	
	   
		cout<<"\tEnter the student name : "; getline(cin,student_name);                         
		cout<<endl;
		cout<<"\tEnter student ID :(1,2,3..) ";getline(cin,student_ID);                   
		cout<<endl<<endl;
	
     	don<<student_name<<endl<<student_ID<<endl;
     	
		cout<<"\t**Student is created successfully!!!"<<endl;
		cout<<"\tDo you want to create another student press(y/n): ";cin>>option;
		if(option=='y')
		i++;
	}
	while(option!='n');
	

	don.close();
	system("cls");
	coe();	
}

void student_login()                                      //  Function for Student login
{ 
 cout<<endl;  
 cout<<"\t\t________________________ <<< Student LOGIN >>> ________________________"<<endl<<endl;
 string name,student_name;
 string ID,student_ID;
 int option;
 
 cin.clear();
 fflush(stdin);
		
 cout<<"\t\t\t\t\tStudent name : ";getline(cin,name);                               
 cout<<endl;
 cout<<"\t\t\t\t\tStudent ID : ";getline(cin,ID);
 cout<<endl;
 
 ifstream read("create.txt");
 
 while(!read.eof())
 { 
    do
    {
	
    getline(read,student_name);

    }while(!read.eof() && student_name != name);
    
    
    if(student_name==name )
   {
    student();
   }
 	else
 	{
	 cout<<"\t\t\t!!!Incorrect ID or Password  ::";
	 system("pause");
	 system("cls");
	 student_login();
    }
    
}
 
 read.close();
 
 }

void verify_Degree()                    //  function for verifying the degree of student
{
  string name[30],course[30];
  string grade[30],semester[30];
  char option;
  int semeseter[30],number;
  
  ofstream file;
  file.open("NCY.txt");
  system("cls");
  int i=0;
  cout<<"\t\t******************************************************************"<<endl<<endl;
  cout<<"\t\t\t\tDegree Verification"<<endl<<endl;
  cout<<"\t\t******************************************************************"<<endl<<endl;

  do
  {
  	cin.clear();
    fflush(stdin);
  	cout<<"\tStudent name : ";getline(cin,name[i]);                             
  	file<<name[i]<<endl;
  	cout<<"\tEnter the number of courses a student had compeleted : ";cin>>number;
  	
  	cout<<"\tEnter Compeleted Courses and Grade in each course :"<<endl;
  	for(int i=1;i<=number;i++)
  	{
  	cout<<"\tEnter the cousre name : ";
  	cin.clear();
    fflush(stdin);
    getline(cin,course[i]);                                           
	file<<course[i]<<endl;
	cout<<"\tEnter the grade in course : ";
	cin>>grade[i];cout<<endl;
	file<<grade[i]<<endl;
	cout<<"\tEnter the semester of completion 1,2,3.. : ";
    cin>>semester[i];cout<<endl;
  	file<<semester[i]<<endl;
	}   
    cout<<"Do you want to verify another student(y/n) : ";cin>>option;
  	if(option=='y')
  	 i++;
  		
   }while(option!='n');
   
   system("cls");
   coe();		
}
	
void student()                                    //  function for student menu
{    
      int option;
      system("cls");
	  cout<<endl;
	  cout<<"************************************************************************************************************************"<<endl<<endl;
	  cout<<"\t\t\tStudent Menu"<<endl<<endl;
	  cout<<"************************************************************************************************************************"<<endl<<endl;
	  cout<<"\t\t\t1.Veiw compeleted courses,semester of completion"<<endl<<endl;
	  cout<<"\t\t\t2.Veiw registered courses"<<endl<<endl;
	  cout<<"\t\t\t3.Logout"<<endl<<endl;
	  cout<<"************************************************************************************************************************"<<endl;
	  cout<<"\t\t\tSelect option(1-3) :";cin>>option;
	  switch(option)
	  {
	  case 1:
	  {
	  verify();
	  break;;
	  }
	  case 2:
	  {
	  system("cls");
      student_courses();
	  break;
	  }
	   case 3:
	  {
	  system("cls");
	  main();
	  break;	
	  }
	   default:
	   cout<<"\t\t You have entered incorrect option ::";
	   system("pause");
	   system("cls");
	   main();
	  }	
}
 

void instructor_login()                       // instructor login function
{
 cin.ignore();
 int number;
 cout<<endl;
 
 string name,instructor_name;
 string ID,instructor_ID,one;
 
 cout<<"\t\t_______________________ <<< INSTRUCTOR LOGIN >>> ________________________"<<endl<<endl;
 cin.clear();
 fflush(stdin);
 
 cout<<"\t\t\t\tInstructor name : ";
 getline(cin,name);
 cout<<endl;
 cout<<"\t\t\t\tInstructor ID : ";
 getline(cin,ID);

 ifstream read;
 read.open("instructor.txt");
 int i=0;
 while(!read.eof())
 { 
    
	do {
		getline(read,instructor_name);                               
		
	} while(!read.eof() && name != instructor_name);
                                                            
    if(instructor_name==name )
   {
    instructor();
   }
   
   else
   {
   	cout<<endl;
	cout<<"\t\t\t!!!Incorrect ID or Password  ::";
	system("pause");
	system("cls");
	instructor_login();
   }  
 }                                        
 read.close();		
 }
  
void veiw_assign_courses()              //  function use to show the assigned courses of instructor
{
  
  system("cls");
  cout<<endl;
  cout<<"******************************************************************"<<endl<<endl;
  cout<<"\t\t\t     Assigned Courses"<<endl<<endl;
  cout<<"******************************************************************"<<endl<<endl;
  string username,course;
  cin.clear();
  fflush(stdin);
  cout<<"\t\t\t Enter instructor name: ";getline(cin,username);
  cout<<endl;
  string name[10];
  string subject[10];
  int one;
  ifstream read;
  read.open("Main.txt");
  int i=0;
  while(!read.eof())
  { 
	
    getline(read,name[i]);
  	read>>subject[i];
  	
  	if(name[i]==username){
    course=subject[i];
	system("pause");
	break;}
    
  }
  
    cout<<"\t\t\t Assigned courses: ";
    cout<<course;
    cout<<endl<<endl<<"\t\t\t *Press 1 to return in instructor menu.";cin>>one;
    if(one==1)
    {
    	system("cls");
    	instructor();
	}
	else
	{
	 cout<<"You have entered incorrect number.";
	 system("pause");
	}
  
    read.close();		
}

void student_courses()                              //  fuction used to show the assigned courses of instructor on his ID
{
	string nam,name[30],course[30];
	int number;
	cout<<"***************************************************"<<endl<<endl;
	cout<<"*\tRegistered Courses"<<endl<<endl;
	cout<<"***************************************************"<<endl<<endl;
	cin.clear();
	fflush(stdin);
	cout<<"\tEnter your name : ";getline(cin,nam);
	cout<<"\tEnter the number of courses registered : ";cin>>number;
	
	ifstream file;
	file.open("file.txt");
	int i=1;
	
	do
	{
	   getline(file,name[i]);                         
	 if(name[i]==nam)
	 {
	  for(i=1;i<=number;i++)
	  file>>course[i];
      }
	 	
			
	}while(!file.eof());
	for(i=1;i<=number;i++)
	 cout<<"\t"<<i<<"."<<course[i]<<endl;
	 system("pause");
	 student();
     file.close();
   		
}

void grading()                                    // function for grading students 
{   
    system("cls");
    cout<<endl;
    int top;
	string name[20],subject[20];
	string grade[20];
	ofstream file;
	file.open("grading.txt");
	cout<<"*********************************************************************************"<<endl<<endl;
	cout<<"\t\t\t\tStudent Grading"<<endl<<endl;
	
	for(int i=0;top!=1;i++)
	{
	getline(cin,name[i]);  
	cout<<"\t\t\tEnter the Student Name : ";getline(cin,name[i]);                  
	cout<<endl;
	file<<subject[i]<<endl;
	cout<<"\t\t\tEnter the Subject name : ";getline(cin,subject[i]);                   
	file<<name[i]<<endl;
	cout<<"\t\t\tEnter the Grade : ";cin>>grade[i];
	cout<<endl<<endl;
	file<<grade[i]<<endl;
	
	cout<<"\t\tPress 1 to stop grading student or another button to proceed further :";cin>>top;
    }    	
	file.close(); 
	system("cls");
	//instructor();	
			
}
void send_message()                           //  function to write message to coe
{ 
  string message;
  int back;
  system("cls");
  ofstream file;
  file.open("fida.txt", ios::trunc);
  cout<<"\t\t******************************************************"<<endl<<endl;
  cout<<"\t\t     Note : Message should contain maximum  40 characters\n\n\t\t\tPress (+) to send message to COE."<<endl<<endl;
  cout<<"\t\t******************************************************"<<endl;
  cout<<"Enter your message."<<endl;

   cin.clear();
   fflush(stdin);	
	
  getline(cin, message);
   file<<message;
   cout<<"\n\n!!!Your message is conveyed to COE"<<endl;
   cout<<"*press 1 to return back into instructor menu.";cin>>back;
   if(back==1)
   {
   system("pause");
   system("cls");
   }
   
  
   file.close();
 
}


void read_message()                        //  function for reading the message of instructor
{
    string message;
	ifstream  file;
	file.open("fida.txt");
	cout<<endl<<"\t\t\t\t<<<<   Message from instructor  >>>>"<<endl;
	int i=1;
	do
	{
		getline(file,message);
		
		cout<<"Message "<<i<<": "<<message<<endl;
		i++;
	}while(!file.eof());
	file.close();
	cout<<endl;
	 system("pause");
	  system("cls");
		coe();

  
}

void course_register()
{ 
  system("cls");
  string name[25],course[25];
  int number;
  char option;
  
  ofstream file;
  file.open("file.txt");
  cout<<"**************************************************************************"<<endl<<endl;
  cout<<"\t\t\t Course Registration "<<endl<<endl;
  cout<<"**************************************************************************"<<endl<<endl;
  int i=0;
  do
  {
  	cin.clear();
	fflush(stdin);
  	cout<<"  Enter the student name : ";getline(cin,name[i]);                          
  	file<<name[i]<<endl<<endl;
  	cout<<"  Enter the number of courses to register for student : ";cin>>number;cout<<endl;
  	cout<<"  Name of courses"<<endl;
  	
  	for(i=1;i<=number;i++)
    {
     cout<<"  "<<i<<".";cin>>course[i];	
     file<<course[i]<<endl;	
    }
    cout<<endl;
	cout<<"Do you want to register courses to another student.(y/n): ";cin>>option; 	
  	if(option=='y')
    i++;	
  }while(option!='n');
  system("cls");
  instructor();
}
void verify()                          // Function for showing completed coursrs of student
{
  system("cls");
  string username;
  int number;
  cout<<"***************************************************************"<<endl<<endl;
  cout<<"\t *COMPLETED COURSES,SEMESTER OF COMPELETION,GRADE*"<<endl;
  cout<<"***************************************************************"<<endl<<endl;
  cout<<"\tEnter the user name : ";cin>>username;
  cout<<"\tEnter the no.of courses you have completed : ";cin>>number;
  string name[30];
  string course[30];
  string grade[30];
  int semester[30],main;	
  
  ifstream jawad;
  jawad.open("NCY.txt");
  int i=0;
  do
  { jawad>>name[i];
  
    if(username==name[i])
   {
	 for(int j=1;j<=number;j++)
    {
    	jawad>>course[j];
    	jawad>>grade[j];
    	jawad>>semester[j];	
	}
   }
   i++;
  }while(!jawad.eof());
   jawad.close();
   for(i=1;i<=number;i++)
  {
  cout<<"\tCourse name : "<<course[i]<<endl<<"\tGrade obtained : "<<grade[i]<<endl<<"\tSemester of Completion : "<<semester[i]<<endl<<endl;}
  cout<<"\t*Press 1 to go to student menu : ";cin>>main;
  if(main==1)
  {
   system("cls");
   student();
  }
  else
  {
  cout<<"Entered incorrect option ";
  }
}

void instructor()             //   Function for outlook of instructor ID
{
	int number;
    cout<<endl;
    
    
   	cin.clear();
 	fflush(stdin);
    
   system("cls");
   cout<<endl;
   cout<<"\t***************************************************************************************************"<<endl<<endl;
   cout<<"\t\t\t\twelcome to your account "<<endl<<endl;
   cout<<"\t***************************************************************************************************"<<endl<<endl;;
   cout<<"\t\t\t\t1.Enter grades of the student in course\n\n\t\t\t\t2.View the list of currently assigned courses.\n\n\t\t\t\t3.Send message to COE\n\n\t\t\t\t4.Register courses for student \n\n\t\t\t\t5.Logout"<<endl<<endl;
   cout<<"\t***************************************************************************************************"<<endl;
   cout<<"\t\t\t\tSelect your option.";
   cin>>number;
  
    switch(number)
   {
   	 case 1:
   	 {
	  grading();
	  break;
     }
     case 2:
     {
      veiw_assign_courses();
      break;
     }
     case 3:
     {
	 send_message();
     break;
     }
     case 4:
     {
     course_register();
     break;
     }
     case 5:
     {
     system("cls");
     main();
     break;	
     }
     default:
     {
	  cout<<endl<<cout<<"\t\tYou have selected incorrect option ::";system("pause");
	 system("cls");
	 }
    }
    instructor();
    
}

void coe_login()                       //  function for Login to COE ID 
{   
    ifstream file;
	file.open("name.txt");
	
    string username[1],name,password,userpassword[1];
    cout<<endl;
	cout<<"\t\t**************************   COE Login   ************************************"<<endl;
	
	cout<<"";
	getline(cin,name);
	cout<<endl;
	cout<<"\t\t\t\t Enter your name : ";
	getline(cin,name);
	cout<<endl;
	cout<<"\t\t\t\t Enter your password : ";
	cin>>password;
	
	int i=0;
	do
	{
	  getline(file,username[i]);
	  getline(file,userpassword[i]);
	 if(username[i]==name  && userpassword[i]==password)
	 {system("cls");
	  coe();
	  } 
	 else
	 {
	 	cout<<"\t\t!Incorrect coe's Name or Password :: ";
	 	system("pause");
	 	system("cls");
	 	coe_login();
	 }
	  	
	}while(!file.eof())	;
	file.close();	
}
 
	  
int prints() {                             //  Fuction for outlook of main page
	int number;
	cout<<endl;
	cout<<"************************************************************************************************************************"<<endl;
	cout<<endl;
	cout<<"\t\t\t\t\t<<<< Select user status>>>>>" <<endl<<endl;
	cout<<"************************************************************************************************************************"<<endl;
	cout<<"\t\tNote : Selecting COE option is mandatory for 1st time user for his registration,"<<endl;
	cout<<"\t\tif you are not first time user than you can select other options as well."<<endl<<endl;
	cout<<"\t\t\t\t\t   1.COE"<<endl<<endl;
	cout<<"\t\t\t\t\t   2.Student"<<endl<<endl;
	cout<<"\t\t\t\t\t   3.Instructor"<<endl<<endl;
	cout<<"************************************************************************************************************************"<<endl;
	cout<<endl;
	cout<<"\t\t\t\t   write (1/2/3)to make your selection :";
	cin>>number;
	cout<<endl;
	return number;
}	
	
 
void change_password()         //  Function for changing passowrd
{   
  int number;
    system("cls");
    string name,password;
     ofstream temp;
     
	 temp.open("temp.txt",ios::trunc);
	 fstream file("name.txt");
	 string new_password;
	 string name_coe;
	 cout<<"\n\n\t\t\t@@@@@@@@@@@@@@ CHANGE PASSWORD @@@@@@@@@@@@@";
	 cin.clear();
    fflush(stdin);

	 cout<<"\n\n\t\t\tEnter your name : ";
	 getline(cin,name_coe);
	 cout<<"\n\n\t\t\tEnter your new password : ";
	 cin>>new_password;
	 
	 while(!file.eof())
	 {
	 	getline(file,name);
	 	getline(file,password);
	 	
	 	if(new_password.compare(password)!=0)
	 	{
	 		temp<<name<<endl;
	 		temp<<password<<endl;
	 		
		}
    }
	file.close();
	temp.close();
	remove("name.txt");
	rename("temp.txt","name.txt");
	ofstream read;
	read.open("name.txt");
	{
	read<<name<<endl;
    read<<new_password<<endl;
		
	}
	cout<<"\n\n\t\t\t Your password is changed!!    \n\n\t\t\t*Press 1 to return to coe menu. ";cin>>number;
	if(number==1)
	{system("cls");
 	coe();}
	else
	system("pause");
	read.close();
	system("cls");
	
} 
