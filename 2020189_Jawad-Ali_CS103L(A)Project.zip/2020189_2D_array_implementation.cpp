#include<iostream>
#include<string>
#include<ctime>
#include<stdlib.h>
#include<windows.h>
#include<stdio.h>

using namespace std;

const int r=3;
const int c=3;

void board_setup(char board[r][c]);
void get_user_input(char board[r][c]);
void display_countdown();
void get_computer_input(char board[r][c]);
void option();
int count_board(char symbol,char board[r][c]);
char check_winner(char board[r][c]);

//char board[3][3]={{' ',' ',' '},{' ',' ',' '},{' ',' ',' '}};
int main()
{
	char board[3][3]={{' ',' ',' '},{' ',' ',' '},{' ',' ',' '}};
    system("cls");
	char choice;
	do
	{
	  system("cls");
	  board_setup(board);
	  if(count_board('X',board) == count_board('O',board))
	  {
	  	cout<<"Player's turn."<<endl;
	  	get_user_input(board);
	  }	
	  else
	  {
		//display_countdown() ;  
	  	get_computer_input(board);
	  }	
      char winner = check_winner(board);
	  if(winner == 'X')
	  {
	  	system("cls");
	  	board_setup(board);
	  	system("color 01");
	  	std::cout<<"Congratulations !!! You have won the game."<< std::endl;
	  	break;
	  }	
	  else if(winner == 'O')
	  {
	  	system("cls");
	  	board_setup(board);
	  	system("color 04");
	  	std::cout<<"Computer won the game."<< std::endl;
	  }
	  else if(winner == 'D')
	  { 
	    system("color 0C");
	  	std::cout<<"Game is draw."<< std::endl;
	  	break;
	  }
	
  }while(true);
  option();
}
void board_setup(char board[r][c])             // function for showing board setup
{   
 //void ouputMatrix(char arr[][100], int matrixRows, int matrixColumns);
   // char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
    cout<<endl<<endl<<endl;
    cout<<"\t\t\t\t_______|* *  TIC TAC TOE GAME  * *|_______"<<endl<<endl;
    cout<<"\t\t\t\t  /___  PROJECT BY : JAWAD ALI _____ /"<<endl;
    
    cout<<endl<<endl<<endl<<endl<<endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<<"  " << board[0][0] << "  |  " << board[0][1]<< "  |  " << board[0][2] << endl;
    cout <<"\t\t\t\t\t   "<< "_____|_____|_____" << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<< "  " << board[1][0] << "  |  " << board[1][1] << "  |  " << board[1][2] << endl;
    cout <<"\t\t\t\t\t   "<< "_____|_____|_____" << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<< "  " << board[2][0] << "  |  " << board[2][1] << "  |  " << board[2][2] << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl << endl;
}

void get_user_input(char board[r][c])           //  funtion for player's turn
{
//	char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	int position,position2;
	while(true)
	{
		cout<<"Select Your row number : ";
		cin>>position;
		cout<<"Select Your coloumn number :";
		cin>>position2;;
		cout<<endl;
		position--;
		position2--;
		
		if(position<0 || position>3  && position2<0 || position2>3)
		{
		  cout<<"Please select your position between 1-9."<<endl;	
		}
		else if(board[position][position2]!=' ')
		{
		  cout<<"Please select an empty position."<<endl;
		}
		else
		{
			board[position][position2]='X';
			break;
		}
	}	
}
	
void display_countdown()              // function for countdown
{
	cout<<"Wait for computer's turn : ";
	int counter=5;
	while(counter!=0)
	{
	 cout<<counter<<" ";
	 counter--;
	 Sleep(800);
	 //system("cls");	
	}
}

void get_computer_input(char board[r][c])          //   function for computer's turn
{  
  // char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
   display_countdown();
  srand(time(0));
   int choice1,choice2;
   do
   {
   	
   	choice1=rand()%3;
   	choice2=rand()%3;
   	
   	
   }while(board[choice1][choice2]!=' ');
   board[choice1][choice2]='O';	
	
}

int count_board(char symbol,char board[r][c])
{   
   //char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	int total=0;
	for(int i=0;i<3;i++)
    {for(int j=0;j<3;j++)
     if(board[i][j] == symbol)
	  total+=1;	
    }
	return total;	
}	

char check_winner(char board[r][c])                     // function to check the winner
{  // char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
  	
	//checking winner horizontally
	if(board[0][0]==board[0][1] && board[0][1]==board[0][2] && board[0][0]!=' ')
	return board[0][0];
	if(board[1][0]==board[1][1] && board[1][1]==board[1][2] && board[1][0]!=' ')
	return board[1][0];
	if(board[2][0]==board[2][1] && board[2][1]==board[2][2] && board[2][0]!=' ')
	return board[2][0];
	
	//check winner vertically
	if(board[0][0]==board[1][0] && board[1][0]==board[2][0] && board[0][0]!=' ')
	return board[0][0];
	if(board[0][1]==board[1][1] && board[1][1]==board[2][1] && board[0][1]!=' ')
	return board[0][1];
	if(board[0][2]==board[1][2] && board[1][2]==board[2][2] && board[0][2]!=' ')
	return board[0][2];
	
	//checking winner diagonally
	if(board[0][0]==board[1][1] && board[1][1]==board[2][2] && board[0][0]!=' ')
	return board[0][0];
	if(board[0][2]==board[1][1] && board[1][1]==board[2][0] && board[0][2]!=' ')
	return board[0][2];
	
	if(count_board('X',board) + count_board('O',board) < 9)
	return 'C';
	
	else
	return 'D';	
}	
void option()
{   
    char option;
	cout<<"Do you want to play again(y/n) : ";cin>>option;
    if(option=='y')
	{
 	system("cls");
	main();
    }
    else
    {
	system("cls");
  	cout<<"\n\nThank you for playing.";
	}
}
/*	void printarray(char board[],int x)
{
	
	for(int x =0;x<9;x++)
	{
		cout<<board[x];
		
	}
	
}*/
void printarray(char board[3][3])
{
	for(int i=0; i<3; i++)
	{
		for(int j=0;j<3;j++)
		{
			cout<<board[i][j];
		}
	}
	
}	
	

