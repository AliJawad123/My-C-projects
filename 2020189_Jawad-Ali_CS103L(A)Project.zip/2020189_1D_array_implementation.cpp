#include<iostream>
#include<string>
#include<ctime>
#include<stdlib.h>
#include<windows.h>
#include<stdio.h>


using namespace std;
void printarray(char board[],int x);
void board_setup(char board[], int x);
void get_user_input(char board[], int x);
void display_countdown();
void get_computer_input(char board[], int x);
int count_board(char symbol, char board[], int x);
char check_winner(char board[], int x);

int main()
{
    char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	char choice;
    system("cls");
    //printarray(board,9);
	do
	{
	  system("cls");
	  board_setup(board,9);
	  if(count_board('X',board,9) == count_board('O',board,9))
	  {
	  	cout<<"Player's turn."<<endl;
	  	get_user_input(board,9);
	  }	
	  else
	  {
		//display_countdown() ;  
	  	get_computer_input(board,9);
	  }	
	  char winner = check_winner(board,9);
	  if(winner == 'X')
	  {
	  	system("cls");
	  	board_setup(board,9);
	  	system("color 0A");
	  	std::cout<<"Congratulations !!! You have won the game."<< std::endl;
	  	break;
	  }	
	  else if(winner == 'O')
	  {
	  	system("cls");
	  	board_setup(board,9);
	  	cout<<"Computer won the game."<<endl;
	  	break;
	  }
	  else if(winner == 'D')
	  {
	  	cout<<"Game is draw."<<endl;
	  	break;
	  }
	}while(true);
	
	cout<<"Do you want to Play again : (y/n)";
	cin>>choice;
	cout<<endl;
	
	switch(choice)
	{
		case 'y':
		{
		 system("cls");
		 main();
		 break;
	    }
		default:
		{
		cout<<"Thanks for Playing with us."<<endl;
		system("pause");
	     }
		
	}
	
 return 0;	
}
void board_setup(char board[], int x)             // function for showing board setup
{   
    // char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
    cout<<endl<<endl<<endl;
    cout<<"\t\t\t\t_______|* *  TIC TAC TOE GAME  * *|_______"<<endl<<endl;
    cout<<"\t\t\t\t  /___  PROJECT BY : JAWAD ALI _____ /"<<endl;
    cout<<endl<<endl<<endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<<"  " << board[0] << "  |  " << board[1] << "  |  " << board[2] << endl;
    cout <<"\t\t\t\t\t   "<< "_____|_____|_____" << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<< "  " << board[3] << "  |  " << board[4] << "  |  " << board[5] << endl;
    cout <<"\t\t\t\t\t   "<< "_____|_____|_____" << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl;
    cout <<"\t\t\t\t\t   "<< "  " << board[6] << "  |  " << board[7] << "  |  " << board[8] << endl;
    cout <<"\t\t\t\t\t   "<< "     |     |     " << endl << endl;
}

void get_user_input(char board[], int x)           //  funtion for player's turn
{
//	char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	int position;
	while(true)
	{
		cout<<"Select Your Position inside Grid 1-9 : ";
		cin>>position;
		cout<<endl;
		position--;
		
		if(position<0 || position>8)
		{
		  cout<<"Please select your position between 1-9."<<endl;	
		}
		else if(board[position]!=' ')
		{
		  cout<<"Please select an empty position."<<endl;
		}
		else
		{
			board[position]='X';
			break;
		}
	}	
}

void display_countdown()              // function for countdown
{
	cout<<"Wait for computer's turn : ";
	int counter=5;
	while(counter!=0)
	{
	 cout<<counter<<" ";
	 counter--;
	 Sleep(1000);
	 //system("cls");	
	}
}

void get_computer_input(char board[], int x)          //   function for computer's turn
{  
   //char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
   display_countdown();
  srand(time(0));
   int choice;
   do
   {
   	
   	choice=rand()%10;
   	
   }while(board[choice]!=' ');
   board[choice]='O';	
	
}	

int count_board(char symbol, char board[],int x)
{   
    //char board[9]={' ',' ',' ',' ',' ',' ',' ',' ',' '};
	int total=0;
	for(int i=0;i<9;i++)
    {
     if(board[i] == symbol)
	  total+=1;	
    }
	return total;	
}	

char check_winner(char board[], int x)                     // function to check the winner
{  
  	
	//checking winner horizontally
	if(board[0]==board[1] && board[1]==board[2] && board[0]!=' ')
	return board[0];
	if(board[3]==board[4] && board[4]==board[5] && board[3]!=' ')
	return board[3];
	if(board[6]==board[7] && board[7]==board[8] && board[6]!=' ')
	return board[6];
	
	//check winner vertically
	if(board[0]==board[3] && board[3]==board[6] && board[0]!=' ')
	return board[0];
	if(board[1]==board[4] && board[4]==board[7] && board[1]!=' ')
	return board[1];
	if(board[2]==board[5] && board[5]==board[8] && board[2]!=' ')
	return board[2];
	
	//checking winner diagonally
	if(board[0]==board[4] && board[4]==board[8] && board[0]!=' ')
	return board[0];
	if(board[2]==board[4] && board[4]==board[6] && board[0]!=' ')
	return board[2];
	
	if(count_board('X',board,9) + count_board('O',board,9) < 9)
	return 'C';
	
	else
	return 'D';	
}	

void printarray(char board[],int x)
{
	
	for(int x =0;x<9;x++)
	{
		cout<<board[x];
		
	}
	
}	
	

